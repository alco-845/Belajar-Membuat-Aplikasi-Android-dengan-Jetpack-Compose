package com.rijaldev.travelist.ui.theme

import androidx.compose.ui.graphics.Color

val Turquoise500 = Color(0xFF11C5C6)
val Blue600 = Color(0xFF1BA0E2)
val Blue500 = Color(0xFF1FAEF1)